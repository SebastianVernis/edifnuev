# 📸 Screenshots - Edificio Admin SaaS

Esta carpeta contiene todos los screenshots y archivos de evidencia capturados durante el testing visual automatizado del sistema SaaS.

## 📁 Estructura de Carpetas

```
screenshots/
├── onboarding/          # Screenshots del flujo de onboarding
├── admin-panel/         # Screenshots del panel de administración
├── bugs/                # Screenshots de bugs encontrados
├── db-validation/       # Resultados de queries de base de datos
├── INDEX.md             # Índice completo de todos los archivos
└── README.md            # Este archivo
```

## 📊 Estadísticas

- **Total de archivos:** 51
- **Screenshots PNG:** 48
- **Archivos JSON:** 3
- **Tamaño total:** 11.63 MB
- **Fecha de captura:** 14 de Diciembre, 2025

## 🎯 Contenido por Carpeta

### 📁 onboarding/ (6 archivos)
Screenshots del flujo de registro y onboarding de nuevos usuarios:
- Landing page (3 screenshots)
- Formulario de registro (2 screenshots)
- Página de verificación OTP (2 screenshots)
- Error de selección de plan (1 screenshot)

### 📁 admin-panel/ (45 archivos)
Screenshots del panel de administración y páginas adicionales:
- Landing page detallada (8 screenshots)
- Registro completo (3 screenshots)
- Crear paquete personalizado (8 screenshots)
- Login (2 screenshots)
- Checkout (2 screenshots)
- Setup edificio (2 screenshots)
- Verificar OTP (2 screenshots)
- Admin sin autenticación (2 screenshots)
- Responsive testing (9 screenshots: mobile, tablet, desktop)
- Console logs (4 screenshots)
- Información técnica (3 archivos JSON)

### 📁 bugs/ (0 archivos)
Carpeta reservada para screenshots de bugs específicos.

### 📁 db-validation/ (0 archivos)
Carpeta reservada para resultados de queries de base de datos.

## 🔍 Archivos Especiales

### JSON Files
1. **54-network-info.json** - Información de red y navegador
2. **55-performance-metrics.json** - Métricas de rendimiento
3. **56-accessibility-info.json** - Información de accesibilidad

## 📝 Cómo Usar Este Directorio

### Ver Screenshots
Los screenshots están organizados por fase de testing. Para ver un screenshot específico:

```bash
# Ver screenshot de landing page
open screenshots/onboarding/01-landing-page.png

# Ver screenshot de registro
open screenshots/onboarding/05-registro-form-empty.png

# Ver screenshot responsive mobile
open screenshots/admin-panel/26-landing-mobile.png
```

### Ver Índice Completo
Para ver el índice completo con todos los archivos y sus descripciones:

```bash
cat screenshots/INDEX.md
```

### Ver Información Técnica
Para ver la información técnica capturada:

```bash
# Network info
cat screenshots/admin-panel/54-network-info.json | jq

# Performance metrics
cat screenshots/admin-panel/55-performance-metrics.json | jq

# Accessibility info
cat screenshots/admin-panel/56-accessibility-info.json | jq
```

## 🎨 Naming Convention

Los screenshots siguen esta convención de nombres:

```
[número]-[descripción]-[variante].png

Ejemplos:
01-landing-page.png
26-landing-mobile.png
35-paquete-50-units.png
ERROR-onboarding.png
```

## 📋 Reportes Relacionados

- **TESTING_VISUAL_REPORT.md** - Reporte completo de testing visual
- **BUGS_FOUND.md** - Reporte detallado de bugs encontrados
- **INDEX.md** - Índice completo de screenshots

## 🔧 Regenerar Screenshots

Para regenerar los screenshots, ejecutar:

```bash
# Testing completo
npm run test:visual

# O manualmente:
node scripts/visual-testing-no-db.js
node scripts/capture-additional-screenshots.js
node scripts/generate-screenshot-index.js
```

## ⚠️ Notas Importantes

1. **Resolución:** Todos los screenshots desktop fueron capturados en 1920x1080
2. **Responsive:** Screenshots responsive en 375x667 (mobile), 768x1024 (tablet), 1920x1080 (desktop)
3. **Formato:** Todos los screenshots están en formato PNG
4. **Tamaño:** El tamaño total de la carpeta es ~11.63 MB
5. **Limitaciones:** Testing realizado sin acceso a base de datos y sin autenticación

## 🚀 Próximos Pasos

Para completar el testing visual:

1. **Configurar acceso a DB** - Obtener `CLOUDFLARE_API_TOKEN`
2. **Limpiar base de datos** - Ejecutar comandos de limpieza
3. **Completar flujo de onboarding** - Obtener código OTP de DB
4. **Testing con autenticación** - Probar admin panel completo
5. **Capturar screenshots de DB** - Validar datos guardados

## 📞 Contacto

Para preguntas o issues relacionados con el testing visual, consultar:
- **TESTING_CHECKLIST.md** - Checklist completo de testing
- **TESTING_VISUAL_REPORT.md** - Reporte detallado
- **BUGS_FOUND.md** - Bugs encontrados

---

**Generado automáticamente por Blackbox AI Testing**  
**Fecha:** 14 de Diciembre, 2025

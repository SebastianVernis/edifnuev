# 📸 Índice de Screenshots - Edificio Admin SaaS

**Fecha:** 14 de diciembre de 2025

---

## 📁 Onboarding

**Total de archivos:** 6

### Screenshots PNG (6)

| # | Archivo | Tamaño | Descripción |
|---|---------|--------|-------------|
| 1 | `01-landing-page.png` | 476.25 KB | Landing Page |
| 2 | `02-landing-features.png` | 478.79 KB | Landing Features |
| 3 | `03-landing-pricing.png` | 473.33 KB | Landing Pricing |
| 4 | `04-landing-console-console.png` | 109.08 KB | Landing Console Console |
| 5 | `05-registro-form-empty.png` | 628.48 KB | Registro Form Empty |
| 6 | `ERROR-onboarding.png` | 639.88 KB | ERROR Onboarding |

---

## 📁 Admin-panel

**Total de archivos:** 45

### Screenshots PNG (42)

| # | Archivo | Tamaño | Descripción |
|---|---------|--------|-------------|
| 1 | `13-landing-hero.png` | 476.25 KB | Landing Hero |
| 2 | `14-landing-features-section.png` | 476.69 KB | Landing Features Section |
| 3 | `15-landing-pricing-section.png` | 476.10 KB | Landing Pricing Section |
| 4 | `16-landing-footer.png` | 473.33 KB | Landing Footer |
| 5 | `17-registro-full-page.png` | 628.48 KB | Registro Full Page |
| 6 | `18-crear-paquete-25-units.png` | 112.59 KB | Crear Paquete 25 Units |
| 7 | `19-crear-paquete-100-units.png` | 115.39 KB | Crear Paquete 100 Units |
| 8 | `20-crear-paquete-300-units.png` | 117.11 KB | Crear Paquete 300 Units |
| 9 | `21-login-page.png` | 31.43 KB | Login Page |
| 10 | `22-checkout-page.png` | 628.48 KB | Checkout Page |
| 11 | `23-setup-edificio-page.png` | 628.48 KB | Setup Edificio Page |
| 12 | `24-admin-no-auth.png` | 64.00 KB | Admin No Auth |
| 13 | `25-inquilino-no-auth.png` | 49.63 KB | Inquilino No Auth |
| 14 | `26-landing-desktop.png` | 476.25 KB | Landing Desktop |
| 15 | `26-landing-mobile.png` | 282.29 KB | Landing Mobile |
| 16 | `26-landing-tablet.png` | 321.46 KB | Landing Tablet |
| 17 | `27-registro-desktop.png` | 628.48 KB | Registro Desktop |
| 18 | `27-registro-mobile.png` | 130.22 KB | Registro Mobile |
| 19 | `27-registro-tablet.png` | 144.44 KB | Registro Tablet |
| 20 | `28-login-desktop.png` | 31.43 KB | Login Desktop |
| 21 | `28-login-mobile.png` | 18.01 KB | Login Mobile |
| 22 | `28-login-tablet.png` | 22.09 KB | Login Tablet |
| 23 | `29-landing-header.png` | 9.12 KB | Landing Header |
| 24 | `30-landing-features-cards.png` | 79.75 KB | Landing Features Cards |
| 25 | `31-landing-pricing-cards.png` | 90.11 KB | Landing Pricing Cards |
| 26 | `32-landing-footer-detail.png` | 11.30 KB | Landing Footer Detail |
| 27 | `33-registro-form-detail.png` | 37.97 KB | Registro Form Detail |
| 28 | `35-paquete-150-units.png` | 115.46 KB | Paquete 150 Units |
| 29 | `35-paquete-250-units.png` | 116.20 KB | Paquete 250 Units |
| 30 | `35-paquete-400-units.png` | 116.51 KB | Paquete 400 Units |
| 31 | `35-paquete-50-units.png` | 115.34 KB | Paquete 50 Units |
| 32 | `40-login-form-detail.png` | 4.67 KB | Login Form Detail |
| 33 | `41-checkout-form-detail.png` | 37.97 KB | Checkout Form Detail |
| 34 | `44-setup-form-detail.png` | 37.97 KB | Setup Form Detail |
| 35 | `45-otp-full-page.png` | 628.48 KB | Otp Full Page |
| 36 | `47-admin-redirect.png` | 64.00 KB | Admin Redirect |
| 37 | `48-inquilino-redirect.png` | 49.63 KB | Inquilino Redirect |
| 38 | `49-404-page.png` | 9.37 KB | 404 Page |
| 39 | `50-console-landing.png` | 476.25 KB | Console Landing |
| 40 | `51-console-registro.png` | 628.48 KB | Console Registro |
| 41 | `52-console-login.png` | 31.43 KB | Console Login |
| 42 | `53-console-paquete.png` | 112.59 KB | Console Paquete |

### Archivos JSON (3)

| # | Archivo | Tamaño | Descripción |
|---|---------|--------|-------------|
| 1 | `54-network-info.json` | 0.42 KB | Network Info |
| 2 | `55-performance-metrics.json` | 0.19 KB | Performance Metrics |
| 3 | `56-accessibility-info.json` | 0.25 KB | Accessibility Info |

---

## 📊 Resumen

- **Total de archivos:** 51
- **Tamaño total:** 11.63 MB
- **Carpetas:** 4
- **Fecha de generación:** 14/12/2025, 8:50:22 a.m.

---

## 📝 Notas

- Todos los screenshots fueron capturados en resolución 1920x1080 (desktop)
- Screenshots responsive fueron capturados en 375x667 (mobile), 768x1024 (tablet), y 1920x1080 (desktop)
- Archivos JSON contienen información técnica (network, performance, accessibility)
- Archivos TXT contienen resultados de queries de base de datos

---

**Índice generado automáticamente por Blackbox AI Testing**
